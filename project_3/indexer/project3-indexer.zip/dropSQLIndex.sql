DROP INDEX Location ON Locations;

DROP TABLE IF EXISTS Locations;