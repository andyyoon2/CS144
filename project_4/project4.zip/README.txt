Team: Last Minute
Andy Yoon
Jiexi Luan

One of our team members had an issue with the VM being unable to 
resolve the google domain in the proxy servlet and had to restart
his VM to resolve the issue. The other team member did not have 
this issue. Other than that, everything was tested using our
Project 3 AAR file because the OAK endpoint was far too laggy.
